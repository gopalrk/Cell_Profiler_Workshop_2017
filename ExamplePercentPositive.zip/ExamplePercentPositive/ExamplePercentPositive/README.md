Image from Jason Mitotic index experiment.
