The images of human cell images were provided by the Jason Mitotic Index Experiment.
